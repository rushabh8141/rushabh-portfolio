# RUSHABH – Portfolio Website 💼

A responsive personal portfolio to showcase my work, experience, and skills as a Data & Tech enthusiast.

## 🛠 Tech Used
- HTML5, CSS3
- GitHub Pages

## 🌐 Live Demo
(Coming soon after deployment)

## ✨ Features
- About Me section
- Skills list
- Projects showcase (with weekly updates)
- Contact links to email, GitHub, and LinkedIn

## 🔧 Upcoming
- Adding weekly projects
- Resume section
- Responsive design improvements
